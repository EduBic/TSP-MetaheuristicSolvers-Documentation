#include "dataread.h"

#include <iostream>
#include <fstream>

using namespace std;

DataRead::DataRead(const char* filename)
{
    ifstream input(filename);

    input >> matrixDimension;
    //cout << "matrixDimension = " << matrixDimension << endl;

    matrixData = new double*[matrixDimension];

    for (unsigned int row = 0; row < matrixDimension; row++) {
        matrixData[row] = new double[matrixDimension];

        for (unsigned int col = 0; col < matrixDimension; col++) {

            input >> matrixData[row][col];
            //cout << matrixData[row][col] << "\t";
        }

        //cout << endl;
    }

    input.close();
}

void DataRead::print() const {
    for (unsigned int row = 0; row < matrixDimension; row++) {
        for (unsigned int col = 0; col < matrixDimension; col++) {
            cout << matrixData[row][col] << "\t";
        }
        cout << endl;
    }

    /*ifstream input(filename);

    input >> matrixDimension;
    cout << "matrixDimension = " << matrixDimension << endl;   

    matrixData = new double[matrixDimension][matrixDimension];

    for (unsigned int row = 0; row < matrixDimension; row++) {

        for (unsigned int col = 0; col < matrixDimension; col++) {

            cout << matrixData[row][col] << endl;
            input >> matrixData[row][col];
            cout << matrixData[row][col] << endl;
        }
    }

    input.close();*/
}

int DataRead::getMatDim() const {
    return this->matrixDimension;
}

double** DataRead::getMatData() const {
    return this->matrixData;
}


