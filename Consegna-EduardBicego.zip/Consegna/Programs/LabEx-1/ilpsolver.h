#ifndef ILPSOLVER_H
#define ILPSOLVER_H

#include "cpxmacro.h"
#include <vector>
#include "dataread.h"

class ILPsolver
{
private:
    Env _env;
    Prob _lp;

public:
    ILPsolver(Env env, Prob lp) : _env(env), _lp(lp) {}

    /**
     * Init cplex problem with instance data
     */
    void setupProblem(const DataRead& data);

    /**
     * Solve current mi problem
     * @param x optimal primal solution of current master
     * @param objval optimal objective value
     */
    void solveProblem(std::vector<double>& x, double& objval);
};

#endif // ILPSOLVER_H
