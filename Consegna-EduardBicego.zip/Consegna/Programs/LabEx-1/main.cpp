#include <iostream>
#include <ctime>
#include <sstream>
#include <sys/time.h>

#include "cpxmacro.h"
#include "dataread.h"
#include "ilpsolver.h"

using namespace std;

// error status and messagge buffer
int status;
char errmsg[BUF_SIZE];

int main(int argc, char const* args[])
{
    //cout << "Start program... " << endl;

    const char* filename;
    //unsigned int timeLimit = 60 * 10;   // 10 mins
    
    
    if (argc <= 1) {
        filename = "./data/12_class.dat";
    } else {
        filename = args[1];
    }

    cout << endl << "Read dat: " << filename << endl;
    //cout << "Time Limit (secs): " << timeLimit << endl;


    DataRead dataReader(filename);

    try {
            DECL_ENV( env );
            DECL_PROB( env, lp );

            ILPsolver solver(env, lp);

            solver.setupProblem(dataReader);

            std::vector<double> x;
            double objval;
            
            clock_t startClock, finishClock;
            timeval  tv1, tv2;

            startClock = clock();
            gettimeofday(&tv1, NULL);
            
            //CHECKED_CPX_CALL(CPXsetintparam, env, CPX_PARAM_CLOCKTYPE, 1); //Use CPU as timer
            //CHECKED_CPX_CALL(CPXsetdblparam, env, CPX_PARAM_TILIM, timeLimit);
            
            solver.solveProblem(x, objval);
            
            finishClock = clock();
            gettimeofday(&tv2, NULL);

            //std::cout << "Objective value: " << objval << std::endl;
            //std::cout << "y vars: " << std::endl;

            /*for (unsigned int j = 0; j < x.size()/2; j++) {
                if (j>0 && j%(dataReader.matDimension) == 0) std::cout << std::endl;
                std::cout << setw(7) << x[j] << " ";
            }

            std::cout << std::endl << "x vars: " << std::endl;

            for (unsigned int j = x.size()/2; j < x.size(); j++) {
                if (j>x.size()/2 && j%(dataReader.matDimension) == 0)
                    std::cout << std::endl;
                std::cout << setw(7) << x[j] << " ";
            }*/
            
            //cout << endl;
            //cout << "in " << (double)(tv2.tv_sec+tv2.tv_usec*1e-6 - (tv1.tv_sec+tv1.tv_usec*1e-6)) << " seconds (user time)" << endl;
            //cout << "in " << (double)(finishClock - startClock) / CLOCKS_PER_SEC << " seconds (CPU time)" << endl;
            //cout << endl;
            
            cout << endl;
            cout << "Value, CPU time" << endl;
            cout << objval << ", " << (double)(finishClock - startClock) / CLOCKS_PER_SEC << endl;

            //debug
            CHECKED_CPX_CALL( CPXwriteprob, env, lp, "final.lp", NULL );

            // free
            CPXfreeprob(env, &lp);
            CPXcloseCPLEX(&env);

    } catch(std::exception& e) {
        std::cout << ">>>EXCEPTION: " << e.what() << std::endl;
    }


    return 0;
}

