#ifndef DATAREAD_H
#define DATAREAD_H


class DataRead
{
private:
    unsigned int matrixDimension;
    double** matrixData;

public:
    DataRead(const char* filename);

    void print() const;
    int getMatDim() const;
    double** getMatData() const;
};

#endif // DATAREAD_H
