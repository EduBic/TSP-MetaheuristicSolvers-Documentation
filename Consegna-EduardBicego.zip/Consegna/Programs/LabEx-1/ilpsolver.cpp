#include "ilpsolver.h"
#include "cpxmacro.h"

void ILPsolver::setupProblem(const DataRead &data) {

    // setup initial LP
    double lb0 = 0.0;
    double ubBin = 1.0;
    double ubReal = CPX_INFBOUND;


    // add y vars [in o.f.: sum{i,j} C_ij y_ij + ...]
    char ytype = 'B';

    for (int i = 0; i < data.getMatDim(); i++) {
        for (int j = 0; j < data.getMatDim(); j++) {
            CHECKED_CPX_CALL( CPXnewcols, _env, _lp, 1, &data.getMatData()[i][j], &lb0, &ubBin, &ytype, NULL );
        }
    }

    // add x vars
    double zeroCoef = 0.0;
    char xtype = 'C';

    for (int i = 0; i < data.getMatDim(); i++) {
        for (int k = 0; k < data.getMatDim(); k++) {
            CHECKED_CPX_CALL( CPXnewcols, _env, _lp, 1, &zeroCoef, &lb0, &ubReal, &xtype, NULL );
        }
    }


    // utils vars
    const int x_init = data.getMatDim() * data.getMatDim();
    int matbeg = 0;


    std::vector<int> idx(data.getMatDim());
    std::vector<double> coef(data.getMatDim());
    std::vector<char> sense(data.getMatDim(), 'E');

    // add source flow constraint [ sum_j:{0,j} x_{0,j} = |N|]
    const double rhsn = data.getMatDim();

    for (int i = 0; i < data.getMatDim(); i++) {
        idx[i] = x_init + i;
        coef[i] = 1.0;
    }

    CHECKED_CPX_CALL( CPXaddrows, _env, _lp, data.getMatDim(), 1, data.getMatDim(), &rhsn, &sense[0], &matbeg, &idx[0], &coef[0], NULL, NULL );


    const double rhs = 1.0;

    // add visit constraint 1 [ sum_j:{i,j} y_{0,j} = 1 i fixed]
    for (int i = 0; i < data.getMatDim(); i++) {
        coef[i] = 1.0;

        for (int j = 0; j < data.getMatDim(); j++) {
            idx[j] = i * data.getMatDim() + j;
        }

        CHECKED_CPX_CALL( CPXaddrows, _env, _lp, data.getMatDim(), 1, data.getMatDim(), &rhs, &sense[0], &matbeg, &idx[0], &coef[0], NULL, NULL );
    }

    // add visit constraint 2 [ sum_j:{i,j} y_{0,j} = 1 j fixed]
    for (int j = 0; j < data.getMatDim(); j++) {
        coef[j] = 1.0;

        for (int i = 0; i < data.getMatDim(); i++) {
            idx[i] = j + i*data.getMatDim();
        }
        CHECKED_CPX_CALL( CPXaddrows, _env, _lp, data.getMatDim(), 1, data.getMatDim(), &rhs, &sense[0], &matbeg, &idx[0], &coef[0], NULL, NULL );
    }


    // add flow constraint [ sum_i: {i,k} x_{i,k} - sum_j: {k,j} x_{k,j} = 1 for each k !=0]
    int doubleN = 2 * data.getMatDim();

    std::vector<int> fc_idx(doubleN);
    std::vector<double> fc_coef(doubleN);
    char sing = 'E';

    for (int k = 1; k < data.getMatDim(); k++) {

        for (int i = 0; i < data.getMatDim(); i++) {
            fc_idx[i] = i*data.getMatDim() + k + x_init;
            fc_coef[i] = 1.0;
        }

        for (int j = 0; j < data.getMatDim(); j++) {
            fc_idx[j + data.getMatDim()] = k*data.getMatDim() + j + x_init;
            fc_coef[j + data.getMatDim()] = - 1.0;
        }

        CHECKED_CPX_CALL( CPXaddrows, _env, _lp, doubleN, 1, doubleN, &rhs, &sing, &matbeg, &fc_idx[0], &fc_coef[0], NULL, NULL );
    }

    // logic flow constraint [ x_{i,j} - |N|*y_{i,j} <= 0 ]
    char twoColsSign = 'L';

    std::vector<int> twoCols(2);
    std::vector<double> twoColsCoef(2);

    const double rhs0 = 0.0;

    for (int i = 0; i < data.getMatDim(); i++) {
        for (int j = 0; j < data.getMatDim(); j++) {

            twoColsCoef[0] = 1.0;
            twoCols[0] = x_init + i * data.getMatDim() + j;

            twoColsCoef[1] = - data.getMatDim();
            twoCols[1] = i * data.getMatDim() + j;

            CHECKED_CPX_CALL( CPXaddrows, _env, _lp, 2, 1, 2, &rhs0, &twoColsSign, &matbeg, &twoCols[0], &twoColsCoef[0], NULL, NULL );
        }
    }

    //CHECKED_CPX_CALL( CPXwriteprob, _env, _lp, "initial.lp", NULL );
}

void ILPsolver::solveProblem(std::vector<double> &x, double &objval) {
    // solve
    CHECKED_CPX_CALL( CPXmipopt, _env, _lp );

    // get current LP obj value
    CHECKED_CPX_CALL( CPXgetobjval, _env, _lp, &objval );

    // get current RESTRICTED LP PRIMAL solution
    int n = CPXgetnumcols(_env, _lp);
    x.resize(n);

    CHECKED_CPX_CALL( CPXgetx, _env, _lp, &x[0], 0, n - 1 );
}
