package com.company;

class Hole {

    private double x;
    private double y;

    Hole(double c_x, double c_y){
       this.x = c_x;
       this.y = c_y;
    }

    double getX(){
        return this.x;
    }

    double getY(){
        return this.y;
    }
}
