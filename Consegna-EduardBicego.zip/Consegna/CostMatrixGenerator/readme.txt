
Open terminal, go into folder "CostMatrixGenerator/src"

Generate a new instance using the following command:

	java com.company.Main <NUM_NODES>
	
It writes new files fb<NUM_NODES>.dat (fb = fake board) and <NUM_NODES>.txt into the src folder.

.dat cointains the symmetric matrix of costs.
.txt cointains the x,y coordinates of every points.

The instance created try to emulate a PCB board.
	
